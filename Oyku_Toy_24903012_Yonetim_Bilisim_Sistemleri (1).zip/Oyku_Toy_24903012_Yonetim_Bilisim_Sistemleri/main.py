import sys
from utils import menu_goster
from islem_yonetimi import gelir_ekle, gider_ekle, islemleri_listele
from dosya_islemleri import csv_kaydet, csv_oku
from analiz import verileri_dataframe_yap, toplam_gelir_gider, aylik_analiz, numpy_istatistik
from gorsellestirme import aylik_grafik, gelir_gider_bar, pasta_grafik

def main():
    dosya_adi = "finans_verileri.csv"
    gelirler, giderler = csv_oku(dosya_adi)
    
    while True:
        menu_goster()
        secim = input("Seçiminizi yapın (1-7): ")
        
        if secim == '1':
            gelir_ekle(gelirler)
        elif secim == '2':
            gider_ekle(giderler)
        elif secim == '3':
            islemleri_listele(gelirler, giderler)
        elif secim == '4':
            df = verileri_dataframe_yap(gelirler, giderler)
            if df.empty:
                print("Henüz hiç veri girmemişsiniz, önce biraz ekleme yapın isterseniz.")
                continue
            
            t_gelir, t_gider = toplam_gelir_gider(df)
            print(f"\n--- ÖZET ANALİZ ---")
            print(f"Toplam Gelir: {t_gelir}")
            print(f"Toplam Gider: {t_gider}")
            print(f"Net Durum: {t_gelir - t_gider}")
            
            istatistikler = numpy_istatistik(df)
            print(f"\n--- İSTATİSTİKLER (NumPy) ---")
            for k, v in istatistikler.items():
                print(f"{k.capitalize()}: {v:.2f}")
                
        elif secim == '5':
            df = verileri_dataframe_yap(gelirler, giderler)
            if df.empty:
                print("Grafik çizebilmek için önce veri girişi yapmanız lazım.")
                continue
            aylik_grafik(df)
            gelir_gider_bar(df)
            pasta_grafik(df)
            
        elif secim == '6':
            csv_kaydet(dosya_adi, gelirler, giderler)
            
        elif secim == '7':
            print("Uygulama kapatılıyor, görüşmek üzere!")
            break
        else:
            print("Yanlış tuşa bastınız galiba, lütfen 1-7 arası bir seçim yapın.")

if __name__ == "__main__":
    main()
