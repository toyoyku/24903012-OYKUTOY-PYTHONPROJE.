import matplotlib.pyplot as plt
import pandas as pd

def aylik_grafik(df):
    """
    Aylık gelir ve giderleri karşılaştıran çizgi grafiği oluşturur.
    """
    if df.empty:
        print("Grafik için veri bulunamadı.")
        return
    
    df['ay'] = df['tarih'].dt.to_period('M').astype(str)
    aylik = df.groupby(['ay', 'tip'])['tutar'].sum().unstack().fillna(0)
    
    aylik.plot(kind='line', marker='o')
    plt.title('Aylık Gelir ve Gider Analizi')
    plt.xlabel('Ay')
    plt.ylabel('Tutar')
    plt.grid(True)
    plt.savefig('aylik_analiz.png')
    plt.show()
    print("Aylık grafik 'aylik_analiz.png' olarak kaydedildi.")

def gelir_gider_bar(df):
    """
    Toplam gelir ve gider değerlerini karşılaştıran sütun grafiği oluşturur.
    """
    if df.empty:
        return
    
    toplamlar = df.groupby('tip')['tutar'].sum()
    toplamlar.plot(kind='bar', color=['green', 'red'])
    plt.title('Toplam Gelir vs Gider')
    plt.ylabel('Tutar')
    plt.savefig('gelir_gider_bar.png')
    plt.show()
    print("Bar grafik 'gelir_gider_bar.png' olarak kaydedildi.")

def pasta_grafik(df):
    """
    Gelir ve gider oranlarını gösteren pasta grafiği oluşturur.
    """
    if df.empty:
        return
        
    toplamlar = df.groupby('tip')['tutar'].sum()
    toplamlar.plot(kind='pie', autopct='%1.1f%%', colors=['green', 'red'])
    plt.title('Gelir/Gider Oranı')
    plt.ylabel('')
    plt.savefig('gelir_gider_pasta.png')
    plt.show()
    print("Pasta grafiği 'gelir_gider_pasta.png' olarak kaydedildi.")
