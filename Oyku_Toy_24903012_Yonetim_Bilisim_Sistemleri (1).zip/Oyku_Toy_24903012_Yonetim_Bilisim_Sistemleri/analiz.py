import pandas as pd
import numpy as np

def verileri_dataframe_yap(gelirler, giderler):
    """
    Gelir ve gider listelerini birleştirerek pandas DataFrame yapısına dönüştürür.
    """
    data = []
    for g in gelirler:
        data.append({'id': g.id, 'tutar': g.tutar, 'tarih': g.tarih, 'aciklama': g.aciklama, 'tip': g.tip})
    for g in giderler:
        data.append({'id': g.id, 'tutar': g.tutar, 'tarih': g.tarih, 'aciklama': g.aciklama, 'tip': g.tip})
    
    if not data:
        return pd.DataFrame(columns=['id', 'tutar', 'tarih', 'aciklama', 'tip'])
        
    df = pd.DataFrame(data)
    df['tarih'] = pd.to_datetime(df['tarih'])
    return df

def toplam_gelir_gider(df):
    """
    DataFrame üzerinden toplam gelir ve toplam gider değerlerini hesaplar.
    """
    if df.empty:
        return 0, 0
    toplam_gelir = df[df['tip'] == 'gelir']['tutar'].sum()
    toplam_gider = df[df['tip'] == 'gider']['tutar'].sum()
    return toplam_gelir, toplam_gider

def aylik_analiz(df):
    """
    Verileri tarihe göre gruplayarak aylık bazda özet analiz oluşturur.
    """
    if df.empty:
        return None
    df['ay'] = df['tarih'].dt.to_period('M')
    aylik = df.groupby(['ay', 'tip'])['tutar'].sum().unstack().fillna(0)
    return aylik

def numpy_istatistik(df):
    """
    NumPy kullanarak veri üzerinde ortalama, minimum, maksimum ve standart sapma hesaplar.
    """
    if df.empty:
        return None
    tutarlar = df['tutar'].to_numpy()
    istatistikler = {
        'ortalama': np.mean(tutarlar),
        'minimum': np.min(tutarlar),
        'maksimum': np.max(tutarlar),
        'std_sapma': np.std(tutarlar)
    }
    return istatistikler
