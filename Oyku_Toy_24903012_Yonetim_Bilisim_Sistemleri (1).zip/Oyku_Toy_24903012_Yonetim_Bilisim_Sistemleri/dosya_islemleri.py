import csv
import os
from finans_modeli import Islem

def csv_kaydet(dosya_adi, gelirler, giderler):
    """
    Tüm gelir ve gider verilerini belirtilen CSV dosyasına kaydeder.
    """
    try:
        with open(dosya_adi, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(['id', 'tutar', 'tarih', 'aciklama', 'tip'])
            for g in gelirler:
                writer.writerow([g.id, g.tutar, g.tarih, g.aciklama, g.tip])
            for g in giderler:
                writer.writerow([g.id, g.tutar, g.tarih, g.aciklama, g.tip])
        print(f"Veriler {dosya_adi} dosyasına kaydedildi.")
    except Exception as e:
        print(f"Dosya kaydetme hatası: {e}")

def csv_oku(dosya_adi):
    """
    CSV dosyasındaki verileri okuyarak gelir ve gider listelerini oluşturur.
    """
    gelirler = []
    giderler = []
    if not os.path.exists(dosya_adi):
        return gelirler, giderler
        
    try:
        with open(dosya_adi, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                islem = Islem(
                    int(row['id']),
                    float(row['tutar']),
                    row['tarih'],
                    row['aciklama'],
                    row['tip']
                )
                if row['tip'] == 'gelir':
                    gelirler.append(islem)
                else:
                    giderler.append(islem)
    except Exception as e:
        print(f"Dosya okuma hatası: {e}")
        
    return gelirler, giderler
