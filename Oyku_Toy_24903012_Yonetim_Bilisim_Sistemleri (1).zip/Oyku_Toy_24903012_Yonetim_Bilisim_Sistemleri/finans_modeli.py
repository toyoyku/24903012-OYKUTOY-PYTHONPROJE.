class Islem:
    """
    Finansal işlemleri temsil eden sınıf.
    """
    def __init__(self, id: int, tutar: float, tarih: str, aciklama: str, tip: str):
        """
        id: int -> İşlem benzersiz kimliği
        tutar: float -> İşlem tutarı
        tarih: str (YYYY-MM-DD) -> İşlem tarihi
        aciklama: str -> İşlem açıklaması
        tip: 'gelir' veya 'gider' -> İşlem tipi
        """
        self.id = id
        self.tutar = tutar
        self.tarih = tarih
        self.aciklama = aciklama
        self.tip = tip

    def __str__(self):
        return f"ID: {self.id} | Tarih: {self.tarih} | Tutar: {self.tutar} | Tip: {self.tip} | Açıklama: {self.aciklama}"
