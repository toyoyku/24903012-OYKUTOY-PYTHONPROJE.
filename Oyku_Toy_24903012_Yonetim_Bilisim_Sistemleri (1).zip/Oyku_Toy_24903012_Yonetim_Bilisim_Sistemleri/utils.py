import datetime

def yeni_id_olustur(liste):
    """
    Verilen listedeki en büyük ID'yi bulup bir artırarak yeni benzersiz ID üretir.
    """
    if not liste:
        return 1
    return max(item.id for item in liste) + 1

def tarih_kontrol(tarih_str):
    """
    Girilen tarihin doğru formatta (YYYY-MM-DD) olup olmadığını kontrol eder.
    """
    try:
        datetime.datetime.strptime(tarih_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def sayi_kontrol(deger):
    """
    Kullanıcıdan alınan değerin sayıya dönüştürülebilir olup olmadığını kontrol eder.
    """
    try:
        float(deger)
        return True
    except ValueError:
        return False

def menu_goster():
    """
    Programın ana menüsünü kullanıcıya ekrana yazdırır.
    """
    print("\n--- Öykü'nün Finans Takip Uygulaması ---")
    print("1. Gelir Ekle")
    print("2. Gider Ekle")
    print("3. Listele")
    print("4. Analiz Yap")
    print("5. Grafik Göster")
    print("6. CSV Kaydet")
    print("7. Çıkış")
    print("-----------------------------------------------")
