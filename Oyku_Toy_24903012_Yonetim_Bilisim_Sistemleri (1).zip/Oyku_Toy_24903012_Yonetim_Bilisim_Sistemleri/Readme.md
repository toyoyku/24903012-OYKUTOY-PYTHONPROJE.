# Kişisel Finans Takip Projem (Python Final)

Bu projeyi Python Programlama II dersinin final ödevi için hazırladım. Uygulama sayesinde kendi gelir ve giderlerimi takip edebiliyorum, verileri CSV olarak kaydedip sonrasında analizler ve grafikler oluşturabiliyorum. Tamamen modüler bir yapıda hazırlamaya çalıştım.

## Öğrenci Bilgileri
- **Ad Soyad:** Öykü Toy
- **Öğrenci No:** 24903012
- **Bölüm:** Yönetim Bilişim Sistemleri

## Proje Yapısı ve Modüller
Proje, yönergelerde belirtilen modüler yapıya uygun olarak aşağıdaki dosyalardan oluşmaktadır:

1. **main.py:** Uygulamanın ana giriş noktasıdır. Kullanıcı menüsünü yönetir ve diğer modülleri koordine eder.
2. **finans_modeli.py:** `Islem` sınıfını içerir. Nesne tabanlı programlama prensiplerine uygun olarak veri yapısını tanımlar.
3. **islem_yonetimi.py:** Gelir/gider ekleme, listeleme ve silme işlemlerini yöneten fonksiyonları içerir.
4. **dosya_islemleri.py:** Verilerin CSV dosyasına kaydedilmesi ve dosyadan okunması işlemlerini gerçekleştirir.
5. **analiz.py:** Pandas ve NumPy kütüphanelerini kullanarak veriler üzerinde istatistiksel ve özet analizler yapar.
6. **gorsellestirme.py:** Matplotlib kütüphanesi ile verileri çizgi, sütun ve pasta grafiklerine dönüştürür.
7. **utils.py:** ID oluşturma, tarih formatı kontrolü ve sayısal giriş kontrolü gibi yardımcı fonksiyonları içerir.

## Kullanılan Veri Yapıları ve Kütüphaneler
- **Listeler:** Gelir ve gider nesnelerini saklamak için kullanılmıştır.
- **Sınıflar (OOP):** Her bir işlem bir `Islem` nesnesi olarak temsil edilir.
- **Pandas:** Verilerin DataFrame yapısına dönüştürülmesi ve gruplandırılması için kullanılmıştır.
- **NumPy:** İstatistiksel hesaplamalar (ortalama, standart sapma vb.) için kullanılmıştır.
- **Matplotlib:** Verilerin görselleştirilmesi için kullanılmıştır.

## Kurulum ve Çalıştırma
Gerekli kütüphaneleri yüklemek için:
```bash
pip install pandas numpy matplotlib
```
Programı çalıştırmak için:
```bash
python main.py
```

## GitHub Repository
- **Repo Linki:** [Öğrenci Tarafından Eklenecektir]
- **Görünürlük:** Private (Gizli)
- **Collaborator:** tohid.yousefi
