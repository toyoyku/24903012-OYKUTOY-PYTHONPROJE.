from finans_modeli import Islem
from utils import yeni_id_olustur, tarih_kontrol, sayi_kontrol

def gelir_ekle(gelirler):
    """
    Kullanıcıdan alınan bilgileri doğrulayarak yeni bir gelir kaydı oluşturur ve listeye ekler.
    """
    try:
        tutar_input = input("Gelir tutarını giriniz: ")
        if not sayi_kontrol(tutar_input):
            print("Hata: Geçersiz tutar!")
            return
        
        tutar = float(tutar_input)
        tarih = input("Tarih giriniz (YYYY-MM-DD): ")
        if not tarih_kontrol(tarih):
            print("Hata: Geçersiz tarih formatı!")
            return
            
        aciklama = input("Açıklama giriniz: ")
        
        yeni_id = yeni_id_olustur(gelirler)
        yeni_gelir = Islem(yeni_id, tutar, tarih, aciklama, 'gelir')
        gelirler.append(yeni_gelir)
        print("Gelir başarıyla eklendi.")
    except Exception as e:
        print(f"Bir hata oluştu: {e}")

def gider_ekle(giderler):
    """
    Kullanıcıdan alınan bilgileri doğrulayarak yeni bir gider kaydı oluşturur ve listeye ekler.
    """
    try:
        tutar_input = input("Gider tutarını giriniz: ")
        if not sayi_kontrol(tutar_input):
            print("Hata: Geçersiz tutar!")
            return
            
        tutar = float(tutar_input)
        tarih = input("Tarih giriniz (YYYY-MM-DD): ")
        if not tarih_kontrol(tarih):
            print("Hata: Geçersiz tarih formatı!")
            return
            
        aciklama = input("Açıklama giriniz: ")
        
        yeni_id = yeni_id_olustur(giderler)
        yeni_gider = Islem(yeni_id, tutar, tarih, aciklama, 'gider')
        giderler.append(yeni_gider)
        print("Gider başarıyla eklendi.")
    except Exception as e:
        print(f"Bir hata oluştu: {e}")

def islemleri_listele(gelirler, giderler):
    """
    Tüm gelir ve gider kayıtlarını düzenli bir formatta ekrana yazdırır.
    """
    print("\n--- GELİR LİSTESİ ---")
    if not gelirler:
        print("Kayıtlı gelir bulunmamaktadır.")
    for g in gelirler:
        print(g)
        
    print("\n--- GİDER LİSTESİ ---")
    if not giderler:
        print("Kayıtlı gider bulunmamaktadır.")
    for g in giderler:
        print(g)

def islem_sil(gelirler, giderler, islem_id):
    """
    Verilen ID'ye sahip işlemi bularak ilgili listeden siler.
    """
    silindi = False
    for i, g in enumerate(gelirler):
        if g.id == islem_id:
            del gelirler[i]
            silindi = True
            break
    
    if not silindi:
        for i, g in enumerate(giderler):
            if g.id == islem_id:
                del giderler[i]
                silindi = True
                break
                
    if silindi:
        print(f"ID {islem_id} olan işlem silindi.")
    else:
        print(f"ID {islem_id} olan işlem bulunamadı.")
